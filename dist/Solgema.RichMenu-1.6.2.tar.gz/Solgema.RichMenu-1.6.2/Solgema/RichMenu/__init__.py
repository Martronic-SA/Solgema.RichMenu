from Products.CMFCore import DirectoryView

GLOBALS = globals()

ATTR = 'Solgema.RichMenu'


def initialize(context):
    """Initializer called when used as a Zope 2 product."""
