Changelog for Solgema.RichMenu
v 1.6.3
-------
Update javascript to hide only visible menu.
Hiding menu with animation can be time consuming and sometimes pointer can return quily on the menu before all animations ended which made the sub menu to remain open but not visible.

v 1.6.2
-------

- Fix missing definition of member in viewlets common class

