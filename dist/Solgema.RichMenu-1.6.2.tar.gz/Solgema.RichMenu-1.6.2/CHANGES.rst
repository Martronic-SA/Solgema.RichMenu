Changelog for Solgema.RichMenu

v 1.6.2
-------

- Fix missing definition of member in viewlets common class

