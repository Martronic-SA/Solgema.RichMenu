Solgema.RichMenu Package Readme
=========================

Overview
--------
Richer Plone main menu with Solgema.RichMenu
You can define submenu position, width, depth, number of columns and also add content like document, folder, image inside the submenu.
In order to set the menu properties, move to one of the folder that compose main menu (ensure to be on the folder and not on the default view)
and click on the "Navigation" action tab.


CHANGES
-------

v. 1.5, 1.6 Various css fixes

v. 1.4 Fix menu 100% width when aligned to left and center
      Better Plone 4 compatibility

v. 1.3 Fix - Navigation action was displayed event if the DX content type hadn't the RichMenu behavior.

v. 1.2 Allow the use of Image in RichMenu content.
